# Building and checking the Lean formalization from scratch

This directory holds **source only** (48 KB). It deliberately excludes the
`.lake/` build tree, which is ~7.5 GB (Mathlib and its dependencies).
Reconstruct it with the commands below.

## Requirements
- ~10 GB free disk (Mathlib's build tree is the bulk of it)
- Network access (to fetch Mathlib's *prebuilt* cache)
- Lean 4 **v4.33.1** / Mathlib **v4.33.1** — pinned in `lean-toolchain` and
  `lake-manifest.json`, so `lake` will select them automatically

## Steps

```bash
# 1. Install the Lean toolchain manager (once per machine)
curl -sSfL https://elan.lean-lang.org/elan-init.sh -o elan-init.sh
sh elan-init.sh -y --default-toolchain none
export PATH="$HOME/.elan/bin:$PATH"

# 2. From this directory, fetch dependencies
lake update              # resolves to the pinned revisions in lake-manifest.json

# 3. Fetch the PREBUILT Mathlib cache — do NOT skip this step
lake exe cache get

# 4. Build and check
lake build               # ~90 s cold on 2 cores, ~7 s warm
./gate.sh                # => PASS (28 theorems, standard axioms only)
```

**Do not compile Mathlib from source.** On a 2-core machine that takes many
hours; `lake exe cache get` downloads the 8,322 prebuilt `.olean` files instead.

## What `gate.sh` checks
1. `lake build` completes successfully.
2. No `sorry`, `admit`, `axiom`, or `native_decide` anywhere in `Artin/*.lean`.
3. Every theorem depends only on Lean's three standard axioms
   (`propext`, `Classical.choice`, `Quot.sound`) — verified by `#print axioms`
   in `Artin/Check.lean`.

Expected output:

```
PASS (28 theorems, standard axioms only)
```

## Files

| file | contents |
|---|---|
| `Artin/PairExclusion.lean` | **this paper's Theorem 3** (pair exclusion), the headline result: `not_both_nonresidue_of_barring_character`, its `IsPrimitiveRoot` form, triple exclusion re-derived from it, and two concrete instances — `not_both_primitiveRoot_five_ten` discharges the barring condition from `p mod 8`, so it assumes no Legendre symbol at all |
| `Artin/TripleExclusion.lean` | **this paper's Theorem 2** (triple exclusion): `not_all_three_nonresidue`, `legendreSym_third_eq_one`, the concrete `(2,5,10)` case, and the composed `*_of_primitiveRoot` variants that discharge the Legendre hypotheses from genuine `IsPrimitiveRoot` facts |
| `Artin/PrimitiveRootBridge.lean` | `isPrimitiveRoot_imp_legendreSym_eq_neg_one` and its integer-argument corollary: a primitive root mod an odd prime is a quadratic non-residue (criterion (1) of the paper) |
| `Artin/Exclusion.lean` | residue-class character `chi10` on `ZMod 40`; shift-by-20 flip; shift-by-40 preservation; exclusion (Paper 1) |
| `Artin/Bridge.lean` | `chi10_eq_legendreSym`: the bridge to Mathlib's genuine `legendreSym`, via the second supplementary law and quadratic reciprocity |
| `Artin/Paper2.lean` | machine-checked refutation of a formula from Paper 2's first draft |
| `Artin/Paper2Rebuild.lean` | Paper 2's rebuilt general counting identity `4N = T - A - B + S` |
| `Artin/Basic.lean` | lake-template boilerplate (`def hello`); imported by nothing, retained only so the manifest covers every shipped file |
| `Artin/Check.lean` | every theorem above restated for the axiom audit (`#print axioms`), including Paper 1's Theorem 1 in `legendreSym` terms |
| `README_LEAN.md` | what is proved, and an explicit list of what is **not** proved |
| `gate.sh` | the pass/fail check described above |

## Provenance
Developed 2026-09-10 alongside the manuscript revision of the same date.
Upstream working copy (with build tree): `/home/work/Projects/artin-lean/artin/`,
git commit `c3b1e50`.

Source SHA-256 (see also `../MANIFEST.sha256`):

```
217f782c2d3938f64cf84c4095743b54bd5b159c589e32ad86ac7abacef49023  Artin/Exclusion.lean
5d6062049509ef5f11b2909104a8a08d38214a49ce2579eac37778b571601ad4  Artin/Bridge.lean
6373b73841e169b2e44e99089bcd815dbe80c149b8d9a4b29acf60096946e2d6  Artin/Check.lean
```
